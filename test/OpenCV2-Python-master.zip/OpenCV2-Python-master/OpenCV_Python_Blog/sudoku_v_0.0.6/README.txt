Hi,

This is the code for visual sudoku solver. It is still under development although it works fine for the given image in the folder. 

I haven't tested it for other images.

Run the "sudoku.py" file in this folder. If you want to try for other images, change code accordingly.

Explanations for first few portions of code can be found in my blog : www.opencvpython.blogspot.com

Regards,

Abid Rahman K.